var financeModel = angular.module('financeModel', []);

financeModel.controller('wages_detail', ['$scope',
    function($scope) {
        $scope.wages_allocation = {
            descript: '请输入您的试用期工资',
            wages_probation: '',
            wages_basic: '',
            wages_post: '',
            wages_performance: '',
            wages_become: ''
        };
        $scope.change_probation = function(newValue, oldValue) {
            if (newValue === oldValue) {
                return;
            }
            if (isNaN(newValue)) {
                $scope.wages_allocation.descript = '请输入数字';
                $scope.wages_allocation.wages_probation = '';
                return;
            }
            $scope.wages_allocation.wages_basic = $scope.wages_allocation.wages_probation / 4 * 5 * 0.5;
            $scope.wages_allocation.wages_post = ($scope.wages_allocation.wages_probation * 100 / 4 * 5 * 0.3) / 100;
            $scope.wages_allocation.wages_performance = ($scope.wages_allocation.wages_probation * 100 / 4 * 5 * 0.2) / 100;
            $scope.wages_allocation.wages_become = ($scope.wages_allocation.wages_probation) / 4 * 5;
        }
        $scope.$watch(function() {
            return $scope.wages_allocation.wages_probation;
        }, $scope.change_probation, true);
    }
]);

financeModel.controller('subsidy_detail', ['$scope',
    function($scope) {
        $scope.subsidy_allocation = {
            descript: '请输入您的工资',
            evasion_descript:'请输入您没有扣个税的钱',
            wages_declare: '',
            evasion: '',
            income: '',
            eat: 330,
            payment: 879.36,
            total: '',
            invoice_total:'',
        };
        $scope.change_declare = function(newValue, oldValue) {
            if (isNaN(newValue)) {
                $scope.subsidy_allocation.descript = '请输入数字';
                $scope.subsidy_allocation.wages_declare = '';
                return;
            }
            if (parseInt(newValue) > 3500) {
            	var new_declare = parseInt(newValue) - 3500;
            	if (new_declare<1500) {
            		$scope.subsidy_allocation.income = new_declare * 0.03;
            	} else if (new_declare<4500) {
            		$scope.subsidy_allocation.income = new_declare * 0.1 - 105;
            	} else if (new_declare<9000) {
            		$scope.subsidy_allocation.income = new_declare * 0.2 - 555;
            	} else if (new_declare<35000) {
            		$scope.subsidy_allocation.income = new_declare * 0.25 - 1005;
            	} else if (new_declare<55000) {
            		$scope.subsidy_allocation.income = new_declare * 0.3 - 2775;
            	} else if (new_declare<80000) {
            		$scope.subsidy_allocation.income = new_declare * 0.35 - 5505;
            	} else if (new_declare>80000) {
            		$scope.subsidy_allocation.income = new_declare * 0.45 - 13505;
            	}else{
            		$scope.subsidy_allocation.income = 0;
            	}
            }else{
            	$scope.subsidy_allocation.income = 0;
            }
            $scope.subsidy_allocation.total = (($scope.subsidy_allocation.eat*100) + ($scope.subsidy_allocation.payment*100))/100;
        }
        $scope.change_evasion = function(newValue, oldValue) {
            if (isNaN(newValue)) {
                $scope.subsidy_allocation.evasion_descript = '请输入数字';
                $scope.subsidy_allocation.evasion = '';
                return;
            }
            $scope.subsidy_allocation.invoice_total = (($scope.subsidy_allocation.eat*100) + ($scope.subsidy_allocation.payment*100) + ($scope.subsidy_allocation.evasion*100))/100;
        }
        $scope.$watch(function() {
            return $scope.subsidy_allocation.wages_declare;
        }, $scope.change_declare, true);
        $scope.$watch(function() {
            return $scope.subsidy_allocation.evasion;
        }, $scope.change_evasion, true);
    }
])
