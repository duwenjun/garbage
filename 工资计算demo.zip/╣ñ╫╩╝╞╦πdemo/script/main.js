require.config({
    paths: {
        "angular": "../framework/angular-1.3.0.14/angular.min",
        "index": "../controller/index"
    }
})

require(['angular', 'index']);
